Documention of Unicorn engine.

* How to compile & install Unicorn.

	http://unicorn-engine.org/docs/

* Tutorial on programming with C & Python languages.

	http://unicorn-engine.org/docs/tutorial.html

* Compare Unicorn & QEMU

	http://unicorn-engine.org/docs/beyond_qemu.html

* Uncorn-Engine Documentation

	https://github.com/kabeor/Unicorn-Engine-Documentation
