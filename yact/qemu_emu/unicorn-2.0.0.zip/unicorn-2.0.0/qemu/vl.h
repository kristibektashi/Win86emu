#ifndef VL_H_
#define VL_H_

int machine_initialize(struct uc_struct *uc);

#endif

